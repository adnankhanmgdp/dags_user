class AppConstants {
  static const String serverApiUrl =
      "https://dagstechnology.in"; //192.168.149.179
  static const String userPhoneNumber = "phone-number";
  static const String userName = "user-name";
  static const String storageUserTokenKey = "user_token ";
  static const String userRegisteredEarlier = "registered-earlier-key";
  static const String openedFirstTime = "opened-first-time";
  static const String locationGranted = "location-granted";
  static const String nameSet = "name-set";
  static const String latitude = "latitude";
  static const String longitude = "longitude";
  static const String razorPayKey = "rzp_live_qBQqm2kPD63d06";
  static int minOrderAmount = 0;
}
