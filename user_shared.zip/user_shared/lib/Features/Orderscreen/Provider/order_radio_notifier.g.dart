// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'order_radio_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$orderRadioNotifierHash() =>
    r'eb8c7ca2a320e30d9b8a3e841571376dc997383c';

/// See also [OrderRadioNotifier].
@ProviderFor(OrderRadioNotifier)
final orderRadioNotifierProvider =
    AutoDisposeNotifierProvider<OrderRadioNotifier, bool>.internal(
  OrderRadioNotifier.new,
  name: r'orderRadioNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$orderRadioNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$OrderRadioNotifier = AutoDisposeNotifier<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
