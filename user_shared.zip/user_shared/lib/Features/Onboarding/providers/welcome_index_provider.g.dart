// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'welcome_index_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$welcome_indHash() => r'fe68309792e02347a282c6d3aada791012f4384a';

/// See also [Welcome_ind].
@ProviderFor(Welcome_ind)
final welcome_indProvider =
    AutoDisposeNotifierProvider<Welcome_ind, int>.internal(
  Welcome_ind.new,
  name: r'welcome_indProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$welcome_indHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Welcome_ind = AutoDisposeNotifier<int>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
