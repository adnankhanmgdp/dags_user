// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'order_item_total_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$orderItemTotalProviderHash() =>
    r'9200c7462d43d1e99afef921c37937a354a16c23';

/// See also [OrderItemTotalProvider].
@ProviderFor(OrderItemTotalProvider)
final orderItemTotalProviderProvider =
    AutoDisposeNotifierProvider<OrderItemTotalProvider, int>.internal(
  OrderItemTotalProvider.new,
  name: r'orderItemTotalProviderProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$orderItemTotalProviderHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$OrderItemTotalProvider = AutoDisposeNotifier<int>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
