// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'applicationprovider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$applicationNotifierHash() =>
    r'96653567b780dbf618aeea0338ac0f3a01fe8118';

/// See also [ApplicationNotifier].
@ProviderFor(ApplicationNotifier)
final applicationNotifierProvider =
    AutoDisposeNotifierProvider<ApplicationNotifier, int>.internal(
  ApplicationNotifier.new,
  name: r'applicationNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$applicationNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ApplicationNotifier = AutoDisposeNotifier<int>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
