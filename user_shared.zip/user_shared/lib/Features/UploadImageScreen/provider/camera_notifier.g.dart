// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'camera_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$cameraNotifierHash() => r'45c38915c397185d6543c02ac065cce2a974b967';

/// See also [CameraNotifier].
@ProviderFor(CameraNotifier)
final cameraNotifierProvider = NotifierProvider<CameraNotifier, bool>.internal(
  CameraNotifier.new,
  name: r'cameraNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$cameraNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CameraNotifier = Notifier<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
